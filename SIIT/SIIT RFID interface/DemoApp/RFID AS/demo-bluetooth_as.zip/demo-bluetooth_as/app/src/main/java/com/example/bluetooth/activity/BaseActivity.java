package com.example.bluetooth.activity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import com.example.bluetooth.R;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Activity基类
 * @author wushengjun
 * @date 2016年8月15日
 */
public class BaseActivity extends Activity {
	public static final int REQUESTCODE_BLUETOOTH_ENABLE = 1;
	public static final int REQUESTCODE_BLUETOOTH_OPENSETTING = 2;
	public static final int REQUESTCODE_CHOOSE_FILE = 3;
	public static final int REQUESTCODE_SEND_FILE = 4098;

	public static final int HANDLER_MSG_WHAT_READ = 100;
	public static final int HANDLER_MSG_WHAT_WRITE = 101;
	public static final int HANDLER_MSG_WHAT_DEVICE_NAME = 102;
	public static final int HANDLER_MSG_WHAT_CONN_FAIL = 404;
	public static final int HANDLER_MSG_WHAT_CONN_OFF = 405;
	
 // Unique UUID for this application
    public static final UUID MY_UUID = UUID
            .fromString("00001101-0000-1000-8000-00805F9B34FB"); 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	
	public void gotoActivity(Intent intent) {
		this.startActivity(intent);
	}
	public void gotoActivity(Class<? extends Activity> clz) {
		Intent intent = new Intent(this, clz);
		this.startActivity(intent);
	}
	
	public void toastMessage(String msg) {
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}
	public void toastMessage(int resId) {
		Toast.makeText(this, resId, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * 返回指定时间戳指定格式的时间字符串
	 * @param pattern 格式
	 * @param time 时间戳
	 * @return
	 */
	public String getDateFormat(String pattern, long time) {
		SimpleDateFormat sdf = (SimpleDateFormat) SimpleDateFormat.getDateInstance();
		sdf.applyPattern(pattern);
		Date date = new Date(time);
		return sdf.format(date);
	}
	
	/**
	 * 通过蓝牙发送文件
	 * @param filePath 发送的文件绝对路径
	 */
    public void sendFile(String filePath) {
        PackageManager localPackageManager = getPackageManager();
        Intent localIntent = null;

        HashMap<String, ActivityInfo> localHashMap = null;

        try {
            localIntent = new Intent();
            localIntent.setAction(Intent.ACTION_SEND);
            File file = new File(filePath); //创建发送的文件对象
            localIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            localIntent.setType("*/*");
            List<ResolveInfo> localList = localPackageManager.queryIntentActivities(
                    localIntent, 0);
            localHashMap = new HashMap<String, ActivityInfo>();
            Iterator<ResolveInfo> localIterator = localList.iterator();
            while (localIterator.hasNext()) {
                ResolveInfo resolveInfo = (ResolveInfo) localIterator.next();
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                String str = activityInfo.applicationInfo.processName;
                if (str.contains("bluetooth"))
                    localHashMap.put(str, activityInfo);
            }
        } catch (Exception localException) {
            toastMessage("Exception:" + localException.getMessage());
        }
        if (localHashMap.size() == 0) {
        	toastMessage("localHashMap.size() == 0");
        }
            
        //获取第一种蓝牙的activity类型
        ActivityInfo localActivityInfo = (ActivityInfo) localHashMap.get("com.android.bluetooth");
        
        if (localActivityInfo == null) { //如果第一种为null，则创建第二种
        	//获取第二种蓝牙的activity类型
        	localActivityInfo = (ActivityInfo) localHashMap.get("com.mediatek.bluetooth");
        }
        if (localActivityInfo == null) { //前两种还为null，则获取第三种
            Iterator<ActivityInfo> localIterator2 = localHashMap.values().iterator();
            if (localIterator2.hasNext()) {
                localActivityInfo = (ActivityInfo) localIterator2.next();
            }
        } 

        /*
         * 选择接收方设备发送文件
         */
        if(localActivityInfo != null) {
            localIntent.setComponent(new ComponentName(
                    localActivityInfo.packageName, localActivityInfo.name));
            startActivityForResult(localIntent, REQUESTCODE_SEND_FILE);
        } else {
        	toastMessage(R.string.msg_sendfile_fail);
        }
    }

}
