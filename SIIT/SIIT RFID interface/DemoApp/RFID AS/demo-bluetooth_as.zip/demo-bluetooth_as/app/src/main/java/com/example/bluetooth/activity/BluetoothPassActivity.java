package com.example.bluetooth.activity;

import java.io.IOException;
import java.util.Set;

import com.example.bluetooth.R;
import com.example.bluetooth.filebrowser.FileManagerActivity;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * ���������ļ�Activity
 * @author wushengjun
 * @date 2016��8��15��
 */
public class BluetoothPassActivity extends BaseActivity {

	@ViewInject(R.id.tv_conn_state)
	private TextView tv_conn_state; //��������״̬
	@ViewInject(R.id.tv_file_name)
	private TextView tv_file_name; //ѡ�����ļ�����·��

	private BluetoothAdapter btAdapter;
	private BluetoothDevice btDevice;
	private ArrayAdapter<String> paredDeviceAdapter;
	private AlertDialog dialog; //
	private Set<BluetoothDevice> paredDevice;
	private TextView tv_no;
	private TextView tv_my_device;
	private ListView lv_connected_device;
	
	private ConnectThread mConnectThread;
	
	private String filePath;
	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case HANDLER_MSG_WHAT_CONN_FAIL:
                toastMessage(R.string.msg_conn_fail);
				break;

			default:
				break;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bluetooth_pass);
		
		ViewUtils.inject(this);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		init(); //��ʼ��
	}
	
	private void init() {
		btAdapter = BluetoothAdapter.getDefaultAdapter();
		paredDeviceAdapter = new ArrayAdapter<String>(this, R.layout.item_list1);
		
		if(btAdapter == null) {
			toastMessage(R.string.msg_bluetooth_no_support);
			onBackPressed();
			return;
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(tv_my_device != null) {
			tv_my_device.setText(btAdapter.getName());
		}
		updateParedDevices(); //��������Ե��豸
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if(btAdapter != null) {
			btAdapter.cancelDiscovery();
		}
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@OnClick({R.id.btn_conn_device, R.id.btn_chooseFile, R.id.btn_sendFile, R.id.btn_openBluetooth})
	private void onMyClick(View v) {
		switch (v.getId()) {
		case R.id.btn_conn_device: //�����豸
			if(!btAdapter.isEnabled()) {
				toastMessage(R.string.msg_open_tips);
				requestOpenBluetooth();
			} else {
				showConnectDevice();
			}
			break;
		case R.id.btn_openBluetooth: //������
			if(!btAdapter.isEnabled()) {
				requestOpenBluetooth();
			} else {
				toastMessage(R.string.msg_opened_bluetooth);
			}
			break;
		case R.id.btn_chooseFile: //ѡ���ļ�
			Intent it_openFile = new Intent(this, FileManagerActivity.class);
			startActivityForResult(it_openFile, REQUESTCODE_CHOOSE_FILE);
			break;
		case R.id.btn_sendFile: //�����ļ�
			if(!btAdapter.isEnabled()) {
				toastMessage(R.string.msg_open_tips);
//				requestOpenBluetooth();
			} else if(!TextUtils.isEmpty(filePath)) {
				sendFile(filePath);
			} else {
				toastMessage(R.string.msg_choose_file);
			}
			break;

		default:
			break;
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		switch (requestCode) {
		case REQUESTCODE_BLUETOOTH_ENABLE: //����������
			if(resultCode == Activity.RESULT_OK) { //ͬ�������
				
			} else {
				toastMessage(R.string.msg_bluetooth_open_refuse);
			}
			break;
		case REQUESTCODE_BLUETOOTH_OPENSETTING: //����������ҳ��
			if(resultCode == Activity.RESULT_OK) { //ͬ�������
				
			} else {
				
			}
			break;
		case REQUESTCODE_CHOOSE_FILE: //ѡ���ļ�
			if(resultCode == Activity.RESULT_OK) { //ȷ��ѡ���ļ�
				filePath = data.getStringExtra(FileManagerActivity.EXTRA_FILE_PATH);
				tv_file_name.setText(filePath);
			} else {
				
			}
			break;
		case REQUESTCODE_SEND_FILE: //�����ļ�
			if(resultCode == Activity.RESULT_CANCELED) { //ȡ�������ļ�
//				toastMessage(R.string.msg_sendfile_cancel);
			}
			break;

		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	/**
	 * ��ʾ�����豸����
	 */
	private void showConnectDevice() {
		if(dialog == null) {
			AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
			dialogBuilder.setTitle(R.string.btn_conn_device);
			View dialogView = getLayoutInflater().inflate(R.layout.dialog_bluetooth_connect, null);
			dialogBuilder.setView(dialogView);
			
			tv_my_device = (TextView) dialogView.findViewById(R.id.tv_my_device);
			tv_my_device.setText(btAdapter.getName());
	
			TextView tv_search = (TextView) dialogView.findViewById(R.id.tv_search_device);
			tv_search.setOnClickListener(new View.OnClickListener() {
	
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//����������ҳ��
					Intent intent_conn = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS); 
					startActivityForResult(intent_conn, REQUESTCODE_BLUETOOTH_OPENSETTING);
				}
			});
			tv_no = (TextView) dialogView.findViewById(R.id.tv_no);
			/*ListView */lv_connected_device = (ListView) dialogView.findViewById(R.id.lv_connected_device);
			lv_connected_device.setAdapter(paredDeviceAdapter);
			lv_connected_device.setOnItemClickListener(new AdapterView.OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
					// TODO Auto-generated method stub
					String info = ((TextView) arg1).getText().toString();
		            String address = info.substring(info.length() - 17); //mac��ַ����Ϊ17λ������ð��
		            
		            connectBluetooth(address); //��������豸
		            dialog.dismiss();
				}
			});
			
			this.dialog = dialogBuilder.create();
		} 
		tv_my_device.setText(btAdapter.getName());
		updateParedDevices(); //����������б�
		this.dialog.show();
	}

	/**
	 * ���������
	 */
	private void requestOpenBluetooth() {
		Intent it = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE); //���������
		it.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300); //���������ɼ���
		startActivityForResult(it, REQUESTCODE_BLUETOOTH_ENABLE);
	}
	
	/**
	 * ��������豸
	 * @param address �豸MAC��ֵַ
	 */
	private synchronized void connectBluetooth(String address) {
		btDevice = btAdapter.getRemoteDevice(address);
		
		if(mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}
		
		mConnectThread = new ConnectThread(btDevice);
		mConnectThread.start();
	}
	

	/**
     * This thread runs while attempting to make an outgoing connection with a
     * device. It runs str
     * aight through; the connection either succeeds or
     * fails.
     */
    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        private String TAG = "BluetoothPrintActivity_ConnectThread";

        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            try {
            	tmp = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "create() failed", e);
            }
            mmSocket = tmp;
        }

        public void run() {
            Log.i(TAG, "BEGIN mConnectThread");
//            setName("ConnectThread");

            // Make a connection to the BluetoothSocket
            try {
            	// Always cancel discovery because it will slow down a connection
            	btAdapter.cancelDiscovery(); 
            	
            	// This is a blocking call and will only return on a
            	// successful connection or an exception
                mmSocket.connect();
            } catch (IOException e) {

                Log.e(TAG, e.getMessage());

                mHandler.sendEmptyMessage(HANDLER_MSG_WHAT_CONN_FAIL);
                // Close the socket
                try {
                    mmSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() socket during connection failure", e2);
                }
                // Start the service over to restart listening mode
//                BluetoothService.this.start();
                return;
            }

            // Reset the ConnectThread because we're done
            synchronized (BluetoothPassActivity.this) {
                mConnectThread = null;
            }

            // Start the connected thread
            //            connected(mmSocket, mmDevice);
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
    }

    /**
     * ����������б�
     */
    private void updateParedDevices() {
    	paredDevice = btAdapter.getBondedDevices();
    	paredDeviceAdapter.clear();
    	if(paredDevice.size() > 0) {

    		if(tv_no != null) tv_no.setVisibility(View.GONE);

    		for(BluetoothDevice btDevice : paredDevice) {
    			paredDeviceAdapter.add(btDevice.getName() + "\n" + btDevice.getAddress());
    		}
    	} else {
    		if(tv_no != null) tv_no.setVisibility(View.VISIBLE);
    	}

    	paredDeviceAdapter.notifyDataSetChanged();
    }
}
