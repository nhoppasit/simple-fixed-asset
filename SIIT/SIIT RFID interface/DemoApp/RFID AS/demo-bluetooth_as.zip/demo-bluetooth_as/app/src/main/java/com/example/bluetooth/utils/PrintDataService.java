package com.example.bluetooth.utils;

public class PrintDataService {

}
