package com.example.bluetooth.activity;

import com.example.bluetooth.R;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.event.OnClick;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends BaseActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ViewUtils.inject(this);
	}

	@OnClick({R.id.btn_btPrint, R.id.btn_btPass}) //����xUtils��Դ���ע�ⷽʽʵ���¼���
	private void onMyClick(View v) {
		switch (v.getId()) {
		case R.id.btn_btPrint: //������ӡ
			gotoActivity(BluetoothPrintActivity.class);
			break;
		case R.id.btn_btPass: //�������ļ�
			gotoActivity(BluetoothPassActivity.class);
			break;

		default:
			break;
		}
	}
}
