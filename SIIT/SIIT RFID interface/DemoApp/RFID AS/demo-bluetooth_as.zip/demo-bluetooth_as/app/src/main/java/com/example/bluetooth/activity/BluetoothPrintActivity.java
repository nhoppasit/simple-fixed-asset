package com.example.bluetooth.activity;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Set;

import com.example.bluetooth.R;
import com.example.bluetooth.filebrowser.FileManagerActivity;
import com.example.bluetooth.utils.CreateCodeTool;
import com.example.bluetooth.utils.ImageTool;
import com.google.zxing.BarcodeFormat;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

/**
 * ������ӡActivity
 * @author wushengjun
 * @date 2016��8��15��
 */
public class BluetoothPrintActivity extends BaseActivity {
	public static String TAG = "BluetoothPrintActivity";
	
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    
	private BluetoothAdapter btAdapter;
	private BluetoothDevice btDevice;
	private BluetoothSocket btSocket;
	
	private ConnectThread mConnectThread;
	private PrintThread mPrintThread;
	
	private AlertDialog dialog; //
	private Set<BluetoothDevice> paredDevice;
	private ArrayAdapter<String> paredDeviceAdapter;
	private TextView tv_no;
	private TextView tv_my_device;
	private ListView lv_connected_device;
	
	@ViewInject(R.id.tv_conn_state)
	private TextView tv_conn_state; //��������״̬
	@ViewInject(R.id.et_print_content)
	private EditText et_print_content; //����Ĵ�ӡ����
	@ViewInject(R.id.tv_file_name)
	private TextView tv_file_name; //ѡ�����ļ�����·��
	@ViewInject(R.id.ll_choose_file)
	private LinearLayout ll_choose_file; //

//	@ViewInject(R.id.ll_code_container)
//	private LinearLayout ll_code_container; //
//	@ViewInject(R.id.iv_QRCode)
//	private ImageView iv_QRCode; //���ɵĶ�ά��ͼƬ
//	@ViewInject(R.id.iv_barCode)
//	private ImageView iv_barCode; //���ɵ�һά��ͼƬ
//	@ViewInject(R.id.sp_code_type)
//	private Spinner sp_code_type; //ѡ����
	
	private Bitmap bmp; //���ɵ�һά����ά�����
	
	private int codeType = 1; //�����������ͣ�1��һά�룻2����ά��
	
	private String filePath; //ѡ����ļ�·��
	
	private boolean isFirstObserve = true;
	
    private AlertDialog codeDialog; //��ӡ������ά�봰��
    private TextView tv_printCode_title;
    private EditText et_codeContent;
    private Button btn_codeType, btn_printType;
    private ImageView iv_barCode, iv_QRCode;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bluetooth_print);
		
		ViewUtils.inject(this);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		
		init(); //��ʼ��
	}
	
	private void init() {
		btAdapter = BluetoothAdapter.getDefaultAdapter();
		paredDeviceAdapter = new ArrayAdapter<String>(this, R.layout.item_list1);
		
		if(btAdapter == null) {
			toastMessage(R.string.msg_bluetooth_no_support);
			onBackPressed();
			return;
		}
	}
	
	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case HANDLER_MSG_WHAT_CONN_FAIL: //����ʧ��
                toastMessage(R.string.msg_conn_fail);
				break;
			case HANDLER_MSG_WHAT_CONN_OFF: //���ӶϿ�
				tv_conn_state.setText(R.string.text_conn_off);
				break;
			case HANDLER_MSG_WHAT_READ: //��ȡ��ӡ�ļ�ִ�д�ӡ
				toastMessage(R.string.msg_print_finish);
				break;
			case HANDLER_MSG_WHAT_WRITE:
				toastMessage(R.string.msg_printing);
				break;
			case HANDLER_MSG_WHAT_DEVICE_NAME: //�������豸����
				tv_conn_state.setText(msg.getData().getString(EXTRA_DEVICE_ADDRESS) 
						+ "("+ getString(R.string.text_conned) +")");
				if(isFirstObserve) {
					isFirstObserve = false; //֮������������
					observeConnState(); //��һ�����ӳɹ���ʼ��������״̬
				}
				break;

			default:
				break;
			}
		}
	};
	
	@OnClick({R.id.btn_conn_device, R.id.btn_chooseFile,
		R.id.btn_print, R.id.btn_cancel, R.id.tv_conn_state,
		R.id.btn_print_barCode, R.id.btn_print_QRCode})
	private void onMyClick(View v) {
		switch (v.getId()) {
		case R.id.btn_conn_device: //�����豸
			if(!btAdapter.isEnabled()) {
				toastMessage(R.string.msg_open_tips);
				requestOpenBluetooth();
			} else {
				showConnectDevice();
			}
			break;
		case R.id.btn_chooseFile: //ѡ���ļ�
			Intent it_openFile = new Intent(this, FileManagerActivity.class);
			startActivityForResult(it_openFile, REQUESTCODE_CHOOSE_FILE);
			break;
		case R.id.btn_cancel: //ȡ��ѡ���ļ�
			filePath = null; //����filePath�ļ�·��Ϊnull

			setViewVisible();
			break;
		case R.id.btn_print: //��ӡ
			String content = et_print_content.getText().toString().trim();
			if(filePath == null && TextUtils.isEmpty(content)) {
				toastMessage(R.string.msg_content_null);
				return;
			} 
			
			if(btSocket != null && btSocket.isConnected()) {
				connectedSend(btSocket);
			} else {
				toastMessage(R.string.msg_not_conn);
				showConnectDevice(); //��ʾ���Ӵ���
			}
			break;
		case R.id.btn_print_barCode: //��ӡһά��
			codeType = 1;
			showPrintCodeDialog(R.string.btn_print_barCode, R.string.btn_createBarCode,
					R.string.btn_print_barCode);
			
			clearImage();
			turnBarOrQRCode(); //ת��������ά��
			break;
		case R.id.btn_print_QRCode: //��ӡ��ά��
			codeType = 2;
			showPrintCodeDialog(R.string.btn_print_QRCode, R.string.btn_createQRCode,
					R.string.btn_print_QRCode);

			clearImage();
			turnBarOrQRCode(); //ת��������ά��
			break;
//		case R.id.tv_conn_state: //�Ͽ�����
//			closeSocket();
//			break;

		default:
			break;
		}
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		if(!btAdapter.isEnabled()) { //����û��
			requestOpenBluetooth();
		}
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(tv_my_device != null) {
			tv_my_device.setText(btAdapter.getName());
		}
		updateParedDevices(); //��������Ե��豸
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if(btAdapter != null) {
			btAdapter.cancelDiscovery();
		}
		
		isStop = true; //�رռ�������״̬
		closeSocket(); //�ر�socket����
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		switch (requestCode) {
		case REQUESTCODE_BLUETOOTH_ENABLE: //����������
			if(resultCode == Activity.RESULT_OK) { //ͬ�������
				
			} else {
				toastMessage(R.string.msg_bluetooth_open_refuse);
			}
			break;
		case REQUESTCODE_BLUETOOTH_OPENSETTING: //����������ҳ��
			if(resultCode == Activity.RESULT_OK) { //ͬ�������
				
			} else {
				
			}
			break;
		case REQUESTCODE_CHOOSE_FILE: //ѡ���ļ�
			if(resultCode == Activity.RESULT_OK) { //ȷ��ѡ���ļ�
				filePath = data.getStringExtra(FileManagerActivity.EXTRA_FILE_PATH);
				tv_file_name.setText(getString(R.string.text_file) + filePath);
				
				setViewGone();
			} 
			break;

		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void setViewGone() {
		ll_choose_file.setVisibility(View.VISIBLE);
		et_print_content.setVisibility(View.GONE);
	}
	private void setViewVisible() {
		ll_choose_file.setVisibility(View.GONE);
		et_print_content.setVisibility(View.VISIBLE);
	}
	
	private void turnBarOrQRCode() {
		if(codeType == 1) {
			iv_barCode.setVisibility(View.VISIBLE);
			iv_QRCode.setVisibility(View.GONE);
		} else if(codeType == 2) {
			iv_QRCode.setVisibility(View.VISIBLE);
			iv_barCode.setVisibility(View.GONE);
		}
	}
	
	/**
	 * ��մ�ӡ������ά��Ļ���
	 */
	private void clearImage() {
		et_codeContent.getText().clear();
		
		iv_barCode.setImageBitmap(null);
		iv_QRCode.setImageBitmap(null);
		
		if(bmp != null) {
			bmp.recycle();
			bmp = null;
		}
	}
	
	/**
	 * ��ʾ�����豸����
	 */
	private void showConnectDevice() {
		if(dialog == null) {
			AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
			dialogBuilder.setTitle(R.string.btn_conn_device);
			View dialogView = getLayoutInflater().inflate(R.layout.dialog_bluetooth_connect, null);
			dialogBuilder.setView(dialogView);
			
			tv_my_device = (TextView) dialogView.findViewById(R.id.tv_my_device);
			tv_my_device.setText(btAdapter.getName());
	
			TextView tv_search = (TextView) dialogView.findViewById(R.id.tv_search_device);
			tv_search.setOnClickListener(new View.OnClickListener() {
	
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//����������ҳ��
					Intent intent_conn = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS); 
					startActivityForResult(intent_conn, REQUESTCODE_BLUETOOTH_OPENSETTING);
				}
			});
			tv_no = (TextView) dialogView.findViewById(R.id.tv_no);
			/*ListView */lv_connected_device = (ListView) dialogView.findViewById(R.id.lv_connected_device);
			lv_connected_device.setAdapter(paredDeviceAdapter);
			lv_connected_device.setOnItemClickListener(new AdapterView.OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
					// TODO Auto-generated method stub
					String info = ((TextView) arg1).getText().toString();
		            String address = info.substring(info.length() - 17); //mac��ַ����Ϊ17λ������ð��
		            
		            connectBluetooth(address); //��������豸
		            dialog.dismiss();
				}
			});
			
			this.dialog = dialogBuilder.create();
		} 
		
		tv_my_device.setText(btAdapter.getName());
		
		updateParedDevices(); //����������б�
		this.dialog.show();
	}
	
	/**
	 * ����������б�
	 */
	private void updateParedDevices() {
		paredDevice = btAdapter.getBondedDevices();
		paredDeviceAdapter.clear();
		if(paredDevice.size() > 0) {
			
			if(tv_no != null) tv_no.setVisibility(View.GONE);
			
			for(BluetoothDevice btDevice : paredDevice) {
				paredDeviceAdapter.add(btDevice.getName() + "\n" + btDevice.getAddress());
			}
		} else {
			if(tv_no != null) tv_no.setVisibility(View.VISIBLE);
		}
		
		paredDeviceAdapter.notifyDataSetChanged();
	}
	
	/**
	 * ���������
	 */
	private void requestOpenBluetooth() {
		Intent it = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE); //���������
		it.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300); //���������ɼ���
		startActivityForResult(it, REQUESTCODE_BLUETOOTH_ENABLE);
	}
	
	/**
	 * ��������豸
	 * @param address �豸MAC��ֵַ
	 */
	private synchronized void connectBluetooth(String address) {
		btDevice = btAdapter.getRemoteDevice(address);
		
		if(mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}
		
		mConnectThread = new ConnectThread(btDevice);
		mConnectThread.start();
	}
	
	/**
	 * ���ӳɹ���ִ�еĴ�ӡ
	 * @param socket
	 * @param device
	 */
	private synchronized void connectedSend(BluetoothSocket socket) {
		
		mPrintThread = new PrintThread(socket);
		mPrintThread.start();
	}
	
	/**
     * This thread runs while attempting to make an outgoing connection with a
     * device. It runs str
     * aight through; the connection either succeeds or
     * fails.
     */
    private class ConnectThread extends Thread {
//        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        private String TAG = "BluetoothPrintActivity_ConnectThread";

        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            try {
            	btSocket = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "create() failed", e);
            }
        }

        public void run() {
            Log.i(TAG, "BEGIN mConnectThread");
//            setName("ConnectThread");

            // Make a connection to the BluetoothSocket
            try {
            	
            	if(btSocket == null) {
            		btSocket = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
            	}
            	
            	// Always cancel discovery because it will slow down a connection
            	btAdapter.cancelDiscovery(); 
            	
            	// This is a blocking call and will only return on a
            	// successful connection or an exception
                btSocket.connect();
            } catch (IOException e) {

                Log.e(TAG, e.getMessage());

                mHandler.sendEmptyMessage(HANDLER_MSG_WHAT_CONN_FAIL);
                // Start the service over to restart listening mode
//                BluetoothService.this.start();
                return;
            }

            /**
             * ��ʾ����״̬���������豸����
             */
            Message msg = mHandler.obtainMessage(HANDLER_MSG_WHAT_DEVICE_NAME);
    		Bundle bundle = new Bundle();
    		bundle.putString(EXTRA_DEVICE_ADDRESS, mmDevice.getName());
    		msg.setData(bundle);
    		mHandler.sendMessage(msg);
        }
        
        public void cancel() {
            try {
                btSocket.close();
                mHandler.sendEmptyMessage(HANDLER_MSG_WHAT_CONN_OFF);
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
    }
    
    /**
     * This thread runs during a connection with a remote device. It handles all
     * incoming and outgoing transmissions.
     */
    private class PrintThread extends Thread {
        private InputStream mmInStream;
        private OutputStream mmOutStream;
        private String TAG = "BluetoothActivity_ConnectedThread";
        private String charset = "GB2312"; //��ӡ�����ʽ
        
        public PrintThread(BluetoothSocket socket) {
            Log.d(TAG, "create PrintThread");

            // Get the BluetoothSocket input and output streams
            try {
            	if(bmp != null) {
            		byte[] imageData = ImageTool.getImage(bmp);
            		mmInStream = new ByteArrayInputStream(imageData);
            	} else if(filePath == null) {
            		String content = et_print_content.getText().toString();
            		mmInStream = new ByteArrayInputStream(content.getBytes(charset));
            	} else {
            		mmInStream = new FileInputStream(new File(filePath));
            	}
            	mmOutStream = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "temp sockets not created", e);
            }
        }

        public void run() {
            Log.i(TAG, "BEGIN mConnectedThread");

            int length = -1;
            byte[] bytes = new byte[512]; 
            while(true) {
            	try {
					length = mmInStream.read(bytes);
					if(length > 0) {
						bytes = Arrays.copyOf(bytes, length);
						write(bytes); //ִ�д�ӡ
						
		                // Share the sent message back to the UI Activity
//						Message msg = mHandler.obtainMessage(HANDLER_MSG_WHAT_WRITE, bytes);
//						mHandler.sendMessage(msg);
						
					} else {
						Message msg = mHandler.obtainMessage(HANDLER_MSG_WHAT_READ, bytes);
						mHandler.sendMessage(msg);
						
						if(bmp == null) { //һά��ά���ӡ�Ѿ����д�ӡͷ
							write("\n\n\n".getBytes()); //�������ٴ�ӡ�Ӽ������з����ô�ӡֽ�㹻����
						}
						
						mmInStream.close(); //�ر�������
						break;
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					break;
				} 
            }
        }

        /**
         * Write to the connected OutStream.
         *
         * @param buffer The bytes to write
         */
        public void write(byte[] buffer) {

            Log.i(TAG, "ConnectedThread write()");
            try {

                Log.i(TAG, "ConnectedThread write() buffer=" + new String(buffer));

                mmOutStream.write(buffer);
				
            } catch (IOException e) {
                Log.e(TAG, "Exception during write:---" + e.getMessage());
            }
        }
    }
    
    /**
     * �ر�����
     */
    private void closeSocket() {
    	try {
    		if(btSocket != null && btSocket.isConnected()) {
    			btSocket.close();
    			btSocket = null;
    			
                mHandler.sendEmptyMessage(HANDLER_MSG_WHAT_CONN_OFF);
    		} /*else {
    			toastMessage(R.string.text_no_conn);
    		}*/
        } catch (IOException e) {
            Log.e(TAG, "close() of connect socket failed", e);
        }
    }
    
    private boolean isStop = false;
    private void observeConnState() { //������������״̬�߳�
    	
    	new Thread() {
    		@Override
    		public void run() {
    			while(!isStop) {
    				if(btSocket == null || !btSocket.isConnected()) {
    					mHandler.sendEmptyMessage(HANDLER_MSG_WHAT_CONN_OFF);
    				}
    				
    				try {
						sleep(200);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			}
    		}
    	}.start();
    }
    
    
    /**
     * ��ʾ��ӡ���롢��ά��Ĵ���
     * @param title ���ڱ���
     * @param codeType ����ͼƬ���ͣ�������ά�룩
     * @param printType ��ӡͼƬ���ͣ�������ά�룩
     */
    private void showPrintCodeDialog(String title, String createType, String printType) {
    	if(codeDialog == null) {
    		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    		View dialogView = getLayoutInflater().inflate(R.layout.view_print_code, null);
    		builder.setView(dialogView);
    		
    		tv_printCode_title = (TextView) dialogView.findViewById(R.id.tv_title);
    		et_codeContent = (EditText) dialogView.findViewById(R.id.et_codeContent);
    		btn_codeType = (Button) dialogView.findViewById(R.id.btn_creatCode);
    		btn_printType = (Button) dialogView.findViewById(R.id.btn_printCode);
    		iv_barCode = (ImageView) dialogView.findViewById(R.id.iv_barCode);
    		iv_QRCode = (ImageView) dialogView.findViewById(R.id.iv_QRCode);
    		
    		btn_codeType.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					String codeContent = et_codeContent.getText().toString().trim();
					if(!TextUtils.isEmpty(codeContent)) {
						if(codeType == 1) { //һά��
							
							String regex = "[0-9a-zA-Z]+"; //�����ַ�
							if(codeContent.matches(regex)) {
								bmp = CreateCodeTool.creatBarcode(BluetoothPrintActivity.this, codeContent,
										320, 120, true);
								iv_barCode.setImageBitmap(bmp);
							} else {
								toastMessage(R.string.msg_illegal_char);
							}
						} else if(codeType == 2) { // ��ά��
							bmp = CreateCodeTool.createQRImage(codeContent, 260, 260);
							iv_QRCode.setImageBitmap(bmp);
						}
					} else {
						toastMessage(R.string.msg_code_content_null);
					}
				}
			});
    		
    		btn_printType.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(btSocket != null && btSocket.isConnected() && bmp != null) {
						connectedSend(btSocket);
					} else if(bmp == null) {
						toastMessage(R.string.msg_code_creat_null);
					} else {
						toastMessage(R.string.msg_not_conn);
						showConnectDevice(); //��ʾ���Ӵ���
					}
				}
			});
    		
    		dialogView.findViewById(R.id.btn_dismiss_dialog).setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(codeDialog != null) {
						codeDialog.dismiss();
					}
				}
			});
    		
    		codeDialog = builder.create();
    	}
    	
    	tv_printCode_title.setText(title);
    	btn_codeType.setText(createType);
    	btn_printType.setText(printType);
    	codeDialog.show();
    }
    
    /**
     * ��ʾ��ӡ���롢��ά��Ĵ���
     * @param title ���ڱ���
     * @param codeType ����ͼƬ���ͣ�������ά�룩
     * @param printType ��ӡͼƬ���ͣ�������ά�룩
     */
    private void showPrintCodeDialog(int titleResId, int createTypeResId, int printTypeResId) {
    	showPrintCodeDialog(getString(titleResId), getString(createTypeResId),
    			getString(printTypeResId));
    }
}
