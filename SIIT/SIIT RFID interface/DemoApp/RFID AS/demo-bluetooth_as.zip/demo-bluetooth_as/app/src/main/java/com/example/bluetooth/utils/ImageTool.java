package com.example.bluetooth.utils;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;

/**
 * ͼƬ����������
 * @author WuShengjun
 * @date 2016��10��17��
 */
public class ImageTool {
	public static final int imageWidth = 48;
	
	public static byte[] getImage(Bitmap bmp) {
		int width = bmp.getWidth();
		int height = bmp.getHeight();
		
		bmp = resizeBitmap(bmp, imageWidth * 8, height);
		
		byte[] bt = getImageData(bmp);
		bmp.recycle();
		return bt;
	}

	private static Bitmap resizeBitmap(Bitmap bmp, int w, int h) {
		int width = bmp.getWidth();
		int height = bmp.getHeight();
		
		if(width > w) {
			float scaleWidth = ((float) w) / width;
//			float scaleHeight = ((float) h) / height + 24;
			Matrix matrix = new Matrix();
			matrix.postScale(scaleWidth, scaleWidth);
			Bitmap resizeBmp = Bitmap.createBitmap(bmp, 0, 0, width, height, matrix, true);
			return resizeBmp;
		} else {
			Bitmap resizeBmp = Bitmap.createBitmap(w, height + 24, Config.RGB_565);
			Canvas canvas = new Canvas(resizeBmp);
			Paint paint = new Paint();
			canvas.drawColor(Color.WHITE);
			canvas.drawBitmap(bmp, (w - width) / 2, 0, paint);
			return resizeBmp;
		}
	}
	
	private static byte[] getImageData(Bitmap bmp) {
		byte temp = 0;
		int j = 7, start = 0;
		if(bmp != null) {
			int mWidth = bmp.getWidth();
			int mHeight = bmp.getHeight();
			
			int[] intArray = new int[mWidth * mHeight];
			bmp.getPixels(intArray, 0, mWidth, 0, 0, mWidth, mHeight);
			bmp.recycle();
			
			byte[] data = encodeYUV420SP(intArray, mWidth, mHeight);
			byte[] result = new byte[mWidth * mHeight / 8];
			for(int i=0; i<mWidth*mHeight; i++) {
				temp = (byte) ((byte) (data[i] << j) + temp);
				j--;
				if(j < 0) {
					j = 7;
				}
				
				if(i % 8 == 7) {
					result[start++] = temp;
					temp = 0;
				}
			}
			
			if(j != 7) {
				result[start++] = temp;
			}
			
			int aHeight = 24 - mHeight % 24;
			int perLine = mWidth / 8;
			
			byte[] add = new byte[aHeight * perLine];
			byte[] nresult = new byte[mWidth * mHeight / 8 + aHeight * perLine];
			
			System.arraycopy(result, 0, nresult, 0, result.length);
			System.arraycopy(add, 0, nresult, result.length, add.length);
			
			//��ӡ����
			byte[] byteContent = new byte[(mWidth / 8 + 4) * (mHeight + aHeight)];
			//ÿ�д�ӡͷ
			byte[] byteHead = new byte[4];
			byteHead[0] = (byte) 0x1f;
			byteHead[1] = (byte) 0x10;
			byteHead[2] = (byte) (mWidth / 8);
			byteHead[3] = (byte) 0x00;
			for(int i=0; i< mHeight+aHeight; i++) {
				System.arraycopy(byteHead, 0, byteContent, i
						* (perLine + 4), 4);
				System.arraycopy(nresult, i * perLine, byteContent, i
						* (perLine + 4) + 4, perLine);
			}
			return byteContent;
		}
		return null;
	}
	
	private static byte[] encodeYUV420SP(int[] rgba, int w, int h) {
		final int frameSize = w * h;
		byte[] yuv420sp = new byte[frameSize];
//		int[] U = new int[frameSize];
//		int[] V = new int[frameSize];
//		
//		final int uvWidth = w / 2;
		int r, g, b, y, u, v;
		int index = 0;
		for(int i=0; i<h; i++) {
			for(int j=0; j<w; j++) {
				r = (rgba[index] & 0xff000000) >> 24;
				g = (rgba[index] & 0xff0000) >> 16;
				b = (rgba[index] & 0xff00) >> 8;
				
				//rgb to yuv
				y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
				u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
				v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
				
				// clip y
				// yuv420sp[index++] = (byte) ((y < 0) ? 0 : ((y > 255) ? 255 :
				// y));
				byte temp = (byte) ((y < 0) ? 0 : ((y > 255) ? 255 : y));
				yuv420sp[index++] = temp > 0 ? (byte) 1 : (byte) 0;
			}
		}
		
		return yuv420sp;
	}
	
}
